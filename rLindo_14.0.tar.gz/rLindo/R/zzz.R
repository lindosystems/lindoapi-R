.packageName <- "rLindo"

.onAttach <- function(lib, pkg) {
    rLSgetVersionInfo()
}
