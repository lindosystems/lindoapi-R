
SEXP rcLSgetProgressInfo(SEXP spModel,SEXP snLocation,SEXP snQuery);